--Set ON_ERROR option for the duration of this .sql file
SET OPTION DBA.ON_ERROR = 'NOTIFY_CONTINUE';


--Update H_CUST
BEGIN
    DECLARE @idxMLCustExists char(1);
    SET @idxMLCustExists='F';

    --Drop indexes.
    IF EXISTS(SELECT * FROM SYS.SYSINDEXES WHERE iname = 'JOURNAL_LINK' AND tname = 'H_CUST') THEN
        DROP INDEX "DBA"."H_CUST"."JOURNAL_LINK";
    END IF;
    IF EXISTS(SELECT * FROM SYS.SYSINDEXES WHERE iname = 'TICK_REG_STORE' AND tname = 'H_CUST') THEN
        DROP INDEX "DBA"."H_CUST"."TICK_REG_STORE";
    END IF;
    IF EXISTS(SELECT * FROM SYS.SYSINDEXES WHERE iname = 'idxMLTickDatetime' AND tname = 'H_CUST') THEN
        SET @idxMLCustExists='T';
        DROP INDEX "DBA"."H_CUST"."idxMLTickDatetime";
    END IF;
    commit;
    
    --Drop existing primary key.
    IF (SELECT primary_key FROM sys.syscatalog WHERE tname = 'H_CUST') = 'Y' THEN
        ALTER TABLE "DBA"."H_CUST"
            DROP PRIMARY KEY;
        commit;
    END IF;

    --Add new column "ORDINAL".
    IF NOT EXISTS(SELECT * FROM SYS.SYSCOLUMNS WHERE cname = 'ORDINAL' AND tname = 'H_CUST') THEN
        ALTER TABLE "DBA"."H_CUST"
            ADD ORDINAL	T_ORDINAL	NOT NULL	DEFAULT 1;
    END IF;

    --Make sure STORENUM is not null.
    IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_CUST' AND cname = 'STORENUM') = 'Y' THEN
        IF ((SELECT count(*) FROM "DBA"."H_CUST" WHERE STORENUM IS NULL) > 0) THEN
            UPDATE "DBA"."H_CUST" c
                SET c.STORENUM = (SELECT DISTINCT t.STORENUM FROM "DBA"."H_TICKET" t 
                                       WHERE c.TICKET_ID = t.TICKET_ID AND 
                                             c.TICKET = t.TICKET AND 
                                             c.REGNUM = t.REGNUM) 
                WHERE c.STORENUM IS NULL;
            commit;
        END IF;
    
        ALTER TABLE "DBA"."H_CUST"
            MODIFY STORENUM T_STORENUM NOT NULL;
        commit;
    ELSE
        IF (SELECT coltype FROM sys.syscolumns WHERE tname = 'H_CUST' AND cname = 'STORENUM') <> 'double' THEN
            ALTER TABLE "DBA"."H_CUST"
                MODIFY STORENUM T_STORENUM NOT NULL;
            commit;
        END IF;
    END IF;

    --Make sure TICK_DATETIME is not null.
    IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_CUST' AND cname = 'TICK_DATETIME') = 'Y' THEN
        IF ((SELECT count(*) FROM "DBA"."H_CUST" WHERE TICK_DATETIME IS NULL) > 0) THEN
            UPDATE "DBA"."H_CUST" c
                SET c.TICK_DATETIME = (SELECT DISTINCT t.TICK_DATETIME FROM "DBA"."H_TICKET" t 
                                        WHERE c.TICKET_ID = t.TICKET_ID AND c.STORENUM = t.STORENUM) 
                WHERE c.TICK_DATETIME IS NULL;
            commit;
        END IF;
    
        ALTER TABLE "DBA"."H_CUST"
            MODIFY TICK_DATETIME NOT NULL;
        commit;
    END IF;

    --Make sure CARD_TYPE is not null & is varchar(16).
    IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_CUST' AND cname = 'CARD_TYPE') = 'Y' THEN
        IF ((SELECT count(*) FROM "DBA"."H_CUST" WHERE CARD_TYPE IS NULL) > 0) THEN
            UPDATE "DBA"."H_CUST"
                SET "CARD_TYPE" = 'N/A' WHERE "CARD_TYPE" IS NULL;
            commit;
        END IF;
    
        ALTER TABLE "DBA"."H_CUST"
            MODIFY "CARD_TYPE" varchar(16) NOT NULL;
        commit;
    ELSE
        IF ((SELECT coltype FROM sys.syscolumns WHERE tname = 'H_CUST' AND cname = 'CARD_TYPE') <> 'varchar') AND
           ((SELECT length FROM sys.syscolumns WHERE tname = 'H_CUST' AND cname = 'CARD_TYPE') <> 16) THEN
            ALTER TABLE "DBA"."H_CUST"
                MODIFY "CARD_TYPE" varchar(16) NOT NULL;
            commit;
        END IF;
    END IF;

    --Make sure CUSTOMER is not null.
    IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_CUST' AND cname = 'CUSTOMER') = 'Y' THEN
        IF ((SELECT count(*) FROM "DBA"."H_CUST" WHERE CUSTOMER IS NULL) > 0) THEN
            UPDATE "DBA"."H_CUST"
                SET "CUSTOMER" = 0 WHERE "CUSTOMER" IS NULL;
            commit;
        END IF;
    
        ALTER TABLE "DBA"."H_CUST"
            MODIFY "CUSTOMER" NOT NULL;
        commit;
    END IF;

    --Add/change primary key for H_CUST.
    IF (SELECT primary_key FROM sys.syscatalog WHERE tname = 'H_CUST') = 'N' THEN
        IF EXISTS(SELECT "STORENUM", "TICK_DATETIME", "TICKET_ID", "CARD_TYPE", "CUSTOMER"
                    FROM "DBA"."H_CUST"
                    GROUP BY "STORENUM", "TICK_DATETIME", "TICKET_ID", "CARD_TYPE", "CUSTOMER"
                    HAVING count(*) > 1) THEN
            --Delete any records that violate the new primary key that we want to put in place.
            BEGIN
                DECLARE my_cursor CURSOR FOR
                    SELECT distinct(TICKET_ID) FROM "DBA"."H_CUST"
                        GROUP BY "STORENUM", "TICK_DATETIME", "TICKET_ID", "CARD_TYPE", "CUSTOMER"
                        HAVING count(*) > 1;
                DECLARE @ticketid integer;
                DECLARE err_notfound EXCEPTION FOR SQLSTATE '02000';
    
                OPEN my_cursor;
                MYCURSORLOOP:
                LOOP
                    FETCH NEXT my_cursor INTO @ticketid;
                    IF SQLSTATE = err_notfound THEN
                        LEAVE MYCURSORLOOP;
                    ELSE
                        DELETE FROM "DBA"."H_CUST" WHERE TICKET_ID = @ticketid;
                    END IF;
                END LOOP MYCURSORLOOP;
                CLOSE my_cursor; 
    
                commit;
            END;
        END IF;
        --Create new primary key.
        ALTER TABLE "DBA"."H_CUST"
            ADD PRIMARY KEY ("STORENUM", "TICK_DATETIME", "TICKET_ID", "CARD_TYPE", "CUSTOMER", "ORDINAL");
        commit;
    END IF;
    
    --Add back indexes.
    IF NOT EXISTS(SELECT * FROM SYS.SYSINDEXES WHERE iname = 'TICK_REG_STORE' AND tname = 'H_CUST') THEN
        CREATE INDEX "TICK_REG_STORE" ON "DBA"."H_CUST" ("TICKET", "REGNUM", "STORENUM");
    END IF;
    IF (@idxMLCustExists='T') THEN
        CREATE INDEX "idxMLTickDatetime" ON "DBA"."H_CUST" ("TICK_DATETIME" ASC);
    END IF;
    commit;
END;


--Update H_DISC
BEGIN
    DECLARE @idxMLDiscExists char(1);
    SET @idxMLDiscExists='F';

    --Drop indexes.
    IF EXISTS(SELECT * FROM SYS.SYSINDEXES WHERE iname = 'JOURNAL_LINK' AND tname = 'H_DISC') THEN
        DROP INDEX "DBA"."H_DISC"."JOURNAL_LINK";
    END IF;
    IF EXISTS(SELECT * FROM SYS.SYSINDEXES WHERE iname = 'TICK_REG_STORE' AND tname = 'H_DISC') THEN
        DROP INDEX "DBA"."H_DISC"."TICK_REG_STORE";
    END IF;
    IF EXISTS(SELECT * FROM SYS.SYSINDEXES WHERE iname = 'idxMLTickDatetime' AND tname = 'H_DISC') THEN
        SET @idxMLDiscExists='T';
        DROP INDEX "DBA"."H_DISC"."idxMLTickDatetime";
    END IF;
    commit;
    
    --Drop existing primary key.
    IF (SELECT primary_key FROM sys.syscatalog WHERE tname = 'H_DISC') = 'Y' THEN
        ALTER TABLE "DBA"."H_DISC"
            DROP PRIMARY KEY;
        commit;
    END IF;
    --Make sure STORENUM is not null.
    IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_DISC' AND cname = 'STORENUM') = 'Y' THEN
        IF ((SELECT count(*) FROM "DBA"."H_DISC" WHERE STORENUM IS NULL) > 0) THEN
            UPDATE "DBA"."H_DISC" d
                SET d.STORENUM = (SELECT DISTINCT t.STORENUM FROM "DBA"."H_TICKET" t 
                                       WHERE d.TICKET_ID = t.TICKET_ID AND 
                                             d.TICKET = t.TICKET AND 
                                             d.REGNUM = t.REGNUM) 
                WHERE d.STORENUM IS NULL;
            commit;
        END IF;
    
        ALTER TABLE "DBA"."H_DISC"
            MODIFY STORENUM T_STORENUM NOT NULL;
        commit;
    ELSE
        IF (SELECT coltype FROM sys.syscolumns WHERE tname = 'H_DISC' AND cname = 'STORENUM') <> 'double' THEN
            ALTER TABLE "DBA"."H_DISC"
                MODIFY STORENUM T_STORENUM NOT NULL;
            commit;
        END IF;
    END IF;
    --Make sure TICK_DATETIME is not null.
    IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_DISC' AND cname = 'TICK_DATETIME') = 'Y' THEN
        IF ((SELECT count(*) FROM "DBA"."H_DISC" WHERE TICK_DATETIME IS NULL) > 0) THEN
            UPDATE "DBA"."H_DISC" d
                SET d.TICK_DATETIME = (SELECT DISTINCT DATE(t.TICK_DATETIME) FROM "DBA"."H_TICKET" t 
                                            WHERE d.TICKET_ID = t.TICKET_ID AND d.STORENUM = t.STORENUM) 
                WHERE d.TICK_DATETIME IS NULL;
            commit;
        END IF;
    
        ALTER TABLE "DBA"."H_DISC"
            MODIFY TICK_DATETIME NOT NULL;
        commit;
    END IF;
    --Make sure ID is not null.
    IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_DISC' AND cname = 'ID') = 'Y' THEN
        IF ((SELECT count(*) FROM "DBA"."H_DISC" WHERE "ID" IS NULL) > 0) THEN
            UPDATE "DBA"."H_DISC"
                SET "ID" = 0 WHERE "ID" IS NULL;
            commit;
        END IF;
    
        ALTER TABLE "DBA"."H_DISC"
            MODIFY "ID" NOT NULL;
        commit;
    END IF;
    --Make sure ORDINAL is not null.
    IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_DISC' AND cname = 'ORDINAL') = 'Y' THEN
        IF ((SELECT count(*) FROM "DBA"."H_DISC" WHERE "ORDINAL" IS NULL) > 0) THEN
            UPDATE "DBA"."H_DISC"
                SET "ORDINAL" = 0 WHERE "ORDINAL" IS NULL;
            commit;
        END IF;
    
        ALTER TABLE "DBA"."H_DISC"
            MODIFY "ORDINAL" NOT NULL;
        commit;
    END IF;
    --Apply new primary key.
    IF (SELECT primary_key FROM sys.syscatalog WHERE tname = 'H_DISC') = 'N' THEN
        IF EXISTS(SELECT "STORENUM", "SHIFT_SEQ", "TICK_DATETIME", "TICKET_ID", "ID", "ORDINAL"
                    FROM "DBA"."H_DISC"
                    GROUP BY "STORENUM", "SHIFT_SEQ", "TICK_DATETIME", "TICKET_ID", "ID", "ORDINAL"
                    HAVING count(*) > 1) THEN
            --Delete any records that violate the new primary key that we want to put in place.
            BEGIN
                DECLARE my_cursor CURSOR FOR
                    SELECT distinct(TICKET_ID) FROM "DBA"."H_DISC"
                        GROUP BY "STORENUM", "SHIFT_SEQ", "TICK_DATETIME", "TICKET_ID", "ID", "ORDINAL"
                        HAVING count(*) > 1;
                DECLARE @ticketid integer;
                DECLARE err_notfound EXCEPTION FOR SQLSTATE '02000';
    
                OPEN my_cursor;
                MYCURSORLOOP:
                LOOP
                    FETCH NEXT my_cursor INTO @ticketid;
                    IF SQLSTATE = err_notfound THEN
                        LEAVE MYCURSORLOOP;
                    ELSE
                        DELETE FROM "DBA"."H_DISC" WHERE TICKET_ID = @ticketid;
                    END IF;
                END LOOP MYCURSORLOOP;
                CLOSE my_cursor; 
    
                commit;
            END;
        END IF;
        --Create new primary key.
        ALTER TABLE "DBA"."H_DISC"
            ADD PRIMARY KEY ("STORENUM", "TICK_DATETIME", "TICKET_ID", "ID", "ORDINAL");
        commit;
    END IF;
    
    --Add back indexes.
    IF NOT EXISTS(SELECT * FROM SYS.SYSINDEXES WHERE iname = 'TICK_REG_STORE' AND tname = 'H_DISC') THEN
        CREATE INDEX "TICK_REG_STORE" ON "DBA"."H_DISC" ("TICKET", "REGNUM", "STORENUM");
    END IF;
    IF (@idxMLDiscExists='T') THEN
        CREATE INDEX "idxMLTickDatetime" ON "DBA"."H_DISC" ("TICK_DATETIME" ASC);
    END IF;
    commit;
END;


--Update H_TENDER
IF NOT EXISTS(SELECT * FROM SYS.SYSCOLUMNS WHERE cname = 'SIG_STATUS' AND tname = 'H_TENDER') THEN
    ALTER TABLE "DBA"."H_TENDER"
	ADD SIG_STATUS	char(1)	NULL;
    commit;
END IF;


--Create new table H_BIMT.
IF NOT EXISTS(SELECT * FROM SYS.SYSTABLE WHERE table_name = 'H_BIMT') THEN
    CREATE TABLE "DBA"."H_BIMT" (
        STORENUM    T_STORENUM  NOT NULL,
        TICK_DATETIME   timestamp   NOT NULL,
        REGNUM  T_REGNUM    NOT NULL,
        TICKET  T_TICKET    NOT NULL,
        ELSDATE date    NULL,
        TICKET_ID   integer NOT NULL,
        ORDINAL T_ORDINAL   NOT NULL,
        "TYPE"  char(1) NULL,
        "FORMAT"    char(1) NULL,
        "DATA"  long binary NULL,
        PARENT  char(8) NOT NULL,
        PARENT_ORD  T_ORDINAL   NOT NULL,
        PRIMARY KEY (STORENUM, TICK_DATETIME, TICKET_ID, ORDINAL)
    );
    CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_BIMT" (STORENUM ASC, TICK_DATETIME ASC, REGNUM ASC, TICKET ASC, ORDINAL ASC);
    GRANT ALL ON "DBA"."H_BIMT" TO Journal WITH GRANT OPTION;
END IF;

--Add triggers linking H_BIMT to H_CUST and H_TENDER.
IF not exists(SELECT * FROM SYSTRIGGERS WHERE trigname = 'UPD_BIMT_AFTER_UPD_CUST') THEN
    CREATE TRIGGER "UPD_BIMT_AFTER_UPD_CUST" after update on DBA.H_CUST
    referencing old as oldkey new as newkey
    FOR EACH ROW
    BEGIN
        UPDATE DBA.H_BIMT SET TICK_DATETIME = newkey.TICK_DATETIME, TICKET_ID = newkey.TICKET_ID
            WHERE STORENUM = oldkey.STORENUM AND
                  TICK_DATETIME = oldkey.TICK_DATETIME AND 
                  TICKET_ID = oldkey.TICKET_ID AND
                  PARENT = 'CUST' AND 
                  PARENT_ORD = oldkey.ORDINAL;
    END;
END IF;
IF not exists(SELECT * FROM SYSTRIGGERS WHERE trigname = 'DEL_BIMT_AFTER_DEL_CUST') THEN
    CREATE TRIGGER "DEL_BIMT_AFTER_DEL_CUST" AFTER DELETE ON "DBA"."H_CUST"
    referencing old as oldkey
    FOR EACH ROW
    BEGIN
        DELETE FROM DBA.H_BIMT
            WHERE STORENUM = oldkey.STORENUM AND
                  TICK_DATETIME = oldkey.TICK_DATETIME AND 
                  TICKET_ID = oldkey.TICKET_ID AND
                  PARENT = 'CUST' AND
                  PARENT_ORD = oldkey.ORDINAL;
    END;
END IF;
IF not exists(SELECT * FROM SYSTRIGGERS WHERE trigname = 'UPD_BIMT_AFTER_UPD_TENDER') THEN
    CREATE TRIGGER "UPD_BIMT_AFTER_UPD_TENDER" after update on DBA.H_TENDER
    referencing old as oldkey new as newkey
    FOR EACH ROW
    BEGIN
        UPDATE DBA.H_BIMT SET TICK_DATETIME = newkey.TICK_DATETIME, TICKET_ID = newkey.TICKET_ID
            WHERE STORENUM = oldkey.STORENUM AND
                  TICK_DATETIME = oldkey.TICK_DATETIME AND 
                  TICKET_ID = oldkey.TICKET_ID AND
                  PARENT = 'TENDER' AND 
                  PARENT_ORD = oldkey.ORDINAL;
    END;
END IF;
IF not exists(SELECT * FROM SYSTRIGGERS WHERE trigname = 'DEL_BIMT_AFTER_DEL_TENDER') THEN
    CREATE TRIGGER "DEL_BIMT_AFTER_DEL_TENDER" AFTER DELETE ON "DBA"."H_TENDER"
    referencing old as oldkey
    FOR EACH ROW
    BEGIN
        DELETE FROM DBA.H_BIMT
            WHERE STORENUM = oldkey.STORENUM AND
                  TICK_DATETIME = oldkey.TICK_DATETIME AND 
                  TICKET_ID = oldkey.TICKET_ID AND
                  PARENT = 'TENDER' AND 
                  PARENT_ORD = oldkey.ORDINAL;
    END;
END IF;

--Update H_WASH
--If H_WASH column "CODE" allows nulls, update any record where CODE is null to
--have CODE=0. Then make column "CODE" not null.
IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_WASH' and cname = 'CODE') = 'Y' THEN
    UPDATE "DBA"."H_WASH" SET "CODE" = 0 WHERE "CODE" = NULL;
    COMMIT;;
    ALTER TABLE "DBA"."H_WASH"
        MODIFY "CODE" NOT NULL;
END IF;
--Delete duplicate records from H_WASH.
CREATE TABLE "DBA"."tmp_h_wash" ("STORENUM"	T_STORENUM	NOT NULL,
				"TICK_DATETIME"	timestamp	NOT NULL,
				"REGNUM"	T_REGNUM	NOT NULL,
				"TICKET"	T_TICKET	NOT NULL,
				"ORDINAL"	T_ORDINAL	NOT NULL,
				"ELSDATE"	date	NULL,
				"DESCRIPTION"	varchar(16)	NULL,
				"WASH_PROG"	T_SMALL_ID	NULL,
				"EXP_DATE"	date	NULL,
				"CODE"	varchar(6)	NOT NULL,
				"DPT"	varchar(10)	NULL,
				"PRINTED"	numeric(3,0)	NULL,
				"ticket_id"	integer	NOT NULL);
INSERT INTO "DBA"."tmp_h_wash" (STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID)
  SELECT STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID
    FROM "DBA"."H_WASH"
    GROUP BY STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID
    HAVING count(*) > 1;
COMMIT;
DELETE "DBA"."H_WASH"
    FROM "DBA"."H_WASH" hw,
         "DBA"."tmp_h_wash" thw
    WHERE hw.STORENUM = thw.STORENUM AND 
    	  hw.TICK_DATETIME = thw.TICK_DATETIME AND 
        hw.ORDINAL = thw.ORDINAL AND 
    	  hw.CODE = thw.CODE AND 
    	  hw.TICKET_ID = thw.TICKET_ID;
COMMIT;
INSERT INTO "DBA"."H_WASH" (STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID)
  SELECT STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID
    FROM "DBA"."tmp_h_wash";
COMMIT;
DROP TABLE "DBA"."tmp_h_wash";
COMMIT;
--Add/change primary key for H_WASH.
IF ((SELECT primary_key FROM sys.syscatalog WHERE tname = 'H_WASH') = 'Y') AND
   (((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'STORENUM') = 'N') OR
    ((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'TICK_DATETIME') = 'N') OR
    ((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'ORDINAL') = 'N') OR
    ((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'TICKET_ID') = 'N') OR
    ((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'CODE') = 'N')) THEN
    ALTER TABLE "DBA"."H_WASH"
        DROP PRIMARY KEY;
END IF;
IF (SELECT primary_key FROM sys.syscatalog WHERE tname = 'H_WASH') = 'N' THEN
    ALTER TABLE "DBA"."H_WASH"
        ADD PRIMARY KEY ("STORENUM", "TICK_DATETIME", "ORDINAL", "CODE", "TICKET_ID") WITH HASH SIZE 10;
END IF;
--ML updates.
IF exists (SELECT * FROM sys.syscolumns 
               WHERE tname = 'H_WASH' AND cname = 'ML_UPDATE' AND
                     colno <> (SELECT TOP 1 colno FROM sys.syscolumns 
                                   WHERE tname = 'H_WASH'
                                   ORDER BY colno DESC)) THEN
    ALTER TABLE "DBA"."H_WASH" DROP ML_UPDATE;

    ALTER TABLE "DBA"."H_WASH" ADD ML_UPDATE timestamp;

    COMMIT;
END IF;

--Create/update JOURNAL_LINK indexes on tables.
IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_ACCT' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_ACCT"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_ACCT" ("STORENUM", "tick_datetime", "SHIFT_SEQ", "ACCT_TYPE", "ID");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_CUST' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_CUST"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_CUST" ("STORENUM", "TICK_DATETIME", "REGNUM", "TICKET", "CARD_TYPE", "ORDINAL");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_DISC' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_DISC"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_DISC" ("STORENUM", "TICK_DATETIME", "REGNUM", "TICKET", "ID", "ORDINAL");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_EVENT' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_EVENT"."JOURNAL_LINK";    
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_EVENT" ("STORENUM", "TICK_DATETIME", "REGNUM", "SHIFT_SEQ", "TRANS_TYPE");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_FUEL' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_FUEL"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_FUEL" ("STORENUM", "tick_datetime", "REGNUM", "TICKET", "ORDINAL");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_ITEM' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_ITEM"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_ITEM" ("STORENUM", "TICK_DATETIME", "REGNUM", "TICKET", "ORDINAL");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_PICT' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_PICT"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_PICT" ("STORENUM", "TICK_DATETIME", "REGNUM", "TICKET");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_SHIFT' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_SHIFT"."JOURNAL_LINK";
END IF;
CREATE UNIQUE INDEX "JOURNAL_LINK" ON "DBA"."H_SHIFT" ("STORENUM", "SHIFT_SEQ", "start_datetime", "REGNUM");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_TAX' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_TAX"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_TAX" ("STORENUM", "tick_datetime", "REGNUM", "TICKET");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_TENDER' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_TENDER"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_TENDER" ("STORENUM", "tick_datetime", "REGNUM", "TICKET", "ORDINAL");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_TICKET' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_TICKET"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_TICKET" ("STORENUM", "TICK_DATETIME", "REGNUM", "TICKET");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_WASH' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_WASH"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_WASH" ("STORENUM", "TICK_DATETIME", "REGNUM", "TICKET", "ORDINAL", "CODE");


IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_POUT' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_POUT"."JOURNAL_LINK";
END IF;
IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_POUT' and cname = 'TRAN_CODE') = 'Y' THEN
    UPDATE "DBA"."H_POUT" SET TRAN_CODE = 'N/A'
        WHERE "TRAN_CODE" IS NULL;
    commit;
    ALTER TABLE "DBA"."H_POUT"
        MODIFY "TRAN_CODE" NOT NULL;
    commit;
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_POUT" ("STORENUM", "tick_datetime", "REGNUM", "SHIFT_SEQ", "TRAN_CODE");


commit;


--Reset ON_ERROR option.
SET OPTION DBA.ON_ERROR = 'PROMPT';