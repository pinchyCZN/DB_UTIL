--Set ON_ERROR option for the duration of this .sql file
SET OPTION DBA.ON_ERROR = 'NOTIFY_CONTINUE';


--If H_WASH column "CODE" allows nulls, update any record where CODE is null to
--have CODE=0. Then make column "CODE" not null.
IF (SELECT "nulls" FROM sys.syscolumns WHERE tname = 'H_WASH' and cname = 'CODE') = 'Y' THEN
    UPDATE "DBA"."H_WASH" SET "CODE" = 0 WHERE "CODE" = NULL;
    COMMIT;;
    ALTER TABLE "DBA"."H_WASH"
        MODIFY "CODE" NOT NULL;
END IF;

--Delete duplicate records from H_WASH.
CREATE TABLE "DBA"."tmp_h_wash" ("STORENUM"	T_STORENUM	NOT NULL,
				"TICK_DATETIME"	timestamp	NOT NULL,
				"REGNUM"	T_REGNUM	NOT NULL,
				"TICKET"	T_TICKET	NOT NULL,
				"ORDINAL"	T_ORDINAL	NOT NULL,
				"ELSDATE"	date	NULL,
				"DESCRIPTION"	varchar(16)	NULL,
				"WASH_PROG"	T_SMALL_ID	NULL,
				"EXP_DATE"	date	NULL,
				"CODE"	varchar(6)	NOT NULL,
				"DPT"	varchar(10)	NULL,
				"PRINTED"	numeric(3,0)	NULL,
				"ticket_id"	integer	NOT NULL);
INSERT INTO "DBA"."tmp_h_wash" (STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID)
  SELECT STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID
    FROM "DBA"."H_WASH"
    GROUP BY STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID
    HAVING count(*) > 1;
COMMIT;
DELETE "DBA"."H_WASH"
    FROM "DBA"."H_WASH" hw,
         "DBA"."tmp_h_wash" thw
    WHERE hw.STORENUM = thw.STORENUM AND 
    	  hw.TICK_DATETIME = thw.TICK_DATETIME AND 
        hw.ORDINAL = thw.ORDINAL AND 
    	  hw.CODE = thw.CODE AND 
    	  hw.TICKET_ID = thw.TICKET_ID;
COMMIT;
INSERT INTO "DBA"."H_WASH" (STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID)
  SELECT STORENUM,
				TICK_DATETIME,
				REGNUM,
				TICKET,
				ORDINAL,
				ELSDATE,
				DESCRIPTION,
				WASH_PROG,
				EXP_DATE,
				CODE,
				DPT,
				PRINTED,
				TICKET_ID
    FROM "DBA"."tmp_h_wash";
COMMIT;
DROP TABLE "DBA"."tmp_h_wash";
COMMIT;

--Add/change primary key for H_WASH.
IF ((SELECT primary_key FROM sys.syscatalog WHERE tname = 'H_WASH') = 'Y') AND
   (((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'STORENUM') = 'N') OR
    ((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'TICK_DATETIME') = 'N') OR
    ((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'ORDINAL') = 'N') OR
    ((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'TICKET_ID') = 'N') OR
    ((SELECT in_primary_key FROM sys.syscolumns WHERE tname = 'H_WASH' AND cname = 'CODE') = 'N')) THEN
    ALTER TABLE "DBA"."H_WASH"
        DROP PRIMARY KEY;
END IF;
IF (SELECT primary_key FROM sys.syscatalog WHERE tname = 'H_WASH') = 'N' THEN
    ALTER TABLE "DBA"."H_WASH"
        ADD PRIMARY KEY ("STORENUM", "TICK_DATETIME", "ORDINAL", "CODE", "TICKET_ID") WITH HASH SIZE 10;
END IF;

--Add/change JOURNAL_LINK index for H_WASH.
IF exists(SELECT * FROM SYS.SYSINDEXES WHERE tname = 'H_WASH' AND iname = 'JOURNAL_LINK') THEN
    DROP INDEX "DBA"."H_WASH"."JOURNAL_LINK";
END IF;
CREATE INDEX "JOURNAL_LINK" ON "DBA"."H_WASH" ("STORENUM", "TICK_DATETIME", "REGNUM", "TICKET", "ORDINAL", "CODE");

--ML updates.
IF exists (SELECT * FROM sys.syscolumns 
               WHERE tname = 'H_WASH' AND cname = 'ML_UPDATE' AND
                     colno <> (SELECT TOP 1 colno FROM sys.syscolumns 
                                   WHERE tname = 'H_WASH'
                                   ORDER BY colno DESC)) THEN
    ALTER TABLE "DBA"."H_WASH" DROP ML_UPDATE;

    ALTER TABLE "DBA"."H_WASH" ADD ML_UPDATE timestamp;

    COMMIT;
END IF;


--Reset ON_ERROR option.
SET OPTION DBA.ON_ERROR = 'PROMPT';